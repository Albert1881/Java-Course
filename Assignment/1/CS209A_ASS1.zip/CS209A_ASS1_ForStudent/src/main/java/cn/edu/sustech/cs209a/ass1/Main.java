package cn.edu.sustech.cs209a.ass1;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class Main {
    public static void main(String[] args) throws IOException {
        // This part gives you a brief idea of how the text preprocessing program works.
        // You will not be able to compile and run the program now.
        // But don't worry! Check the methods one by one, and fill the empties with appropriate code,
        // then you can finish this task step by step.
        // Now go and start.
        // hint: You can also search for `TODO` to find all unfinished part.
        // hint: Before your start, read the `Example` class we provided.

        Properties properties;
        try {
            properties = Utils8.loadProperties(args[0]); // load the property file
        } catch (FileNotFoundException e) {
            // prompt user if no config file is given
            throw new IllegalArgumentException();
        }

        // TODO: Read values from config files into those given variables. Examples are given.
        String inputCSVPath = properties.getProperty("InputCSVPath");
        if (inputCSVPath == null) {
            throw new NullPointerException();
        }

        // TODO: read the contents of csv file into csvContents
        String[] csvContents = (Utils8.detectFromUnknownEncoding(inputCSVPath)).split("(\r\n)|\n");

        // TODO: recursively create summaryPath File
        String summaryPath = properties.getProperty("SummaryPath");

        // TODO: recursively create errorPath File
        String errorPath = properties.getProperty("ErrorPath");

        Utils8.createFileRecur(summaryPath);
        Utils8.createFileRecur(errorPath);
        PrintWriter summaryPW = new PrintWriter(new FileWriter(summaryPath), true);
        PrintWriter errorPW = new PrintWriter(new FileWriter(errorPath), true);

        if (summaryPW != null) {
            summaryPW.printf("\"file path\",\"processed line count\",\"processed file size(Bytes)\",\"is align\"\n");
        }
        if (errorPW != null) {
            errorPW.printf("\"original file path\",\"abnormal line\"\n");
        }
        for (int i = 1/* skip the first line, which is the header */; i < csvContents.length; i++) {
            List<String> l = Utils8.readCSVLine(csvContents[i], ',');
            String oriPath = Utils8.removeQuotes(l.get(0));
            try {
                processOneFile(properties, summaryPW, l, oriPath);
            } catch (MyFileException e) {
                if (errorPW != null) {
                    errorPW.printf("\"%s\",\"%d\"\n", oriPath, e.lineCnt);
                }
            }
        }
        if (summaryPW != null) {
            summaryPW.close();
        }
        if (errorPW != null) {
            errorPW.close();
        }
    }

    private static void processOneFile(Properties properties, PrintWriter summaryPW, List<String> l, String oriPath) throws MyFileException {
        String fileContent;
        char targetSeparator = ',';
        String tSeparator = properties.getProperty("TargetSeparator");
        if (tSeparator.length() == 1) {
            targetSeparator = tSeparator.charAt(0);
        }

        String targetLineSeparator = properties.getProperty("TargetLineSeparator", "\n");
        try {
            fileContent = Utils8.detectFromUnknownEncoding(oriPath);
            // all content of the file
        } catch (FileNotFoundException e) {
            throw new MyFileException(-1);
        }
        char separator = Utils8.removeQuotes(l.get(2)).charAt(0);
        String[] fileLines = fileContent.split("(\r\n)|\n");// \r\n or \n
        int lineCnt = fileLines.length;
        // used to record line count
        int currentLine = 0;
        // used to record the possible error (abnormal) line
        int columnOfFirstValidLine = 0;
        // used to detect align

        boolean columnFlag = true, isAlign = true;
        StringBuilder out = new StringBuilder();

        for (String line : fileLines) {
            // TODO: process each line according the requirements
            currentLine += 1;
            if (line.equals("")) {
                lineCnt -= 1;
                continue;
            }
            List<String> columns = Utils8.readCSVLine(line,separator);
//            System.out.println(columns);
            if (columns == null) {
                throw new MyFileException(currentLine);
            }
            if (columnOfFirstValidLine == 0) {
                columnOfFirstValidLine = columns.size();
            } else {
                if (columnOfFirstValidLine != columns.size()) {
                    isAlign = false;
                }
            }
            String convertLine = "";
            for (int i = 0; i < columns.size(); i++) {
                String content = columns.get(i);
                if (i != 0) {
                    convertLine += targetSeparator;
                }
                convertLine += content;
            }

            out.append(convertLine);
            out.append(targetLineSeparator);
        }

        String outPath = Utils8.removeQuotes(l.get(1));
        Utils8.writeAsEncoding(out.toString(), outPath,
                Charset.forName(properties.getProperty("TargetEncoding", "utf-8")));
        if (summaryPW != null) {
            summaryPW.printf("\"%s\",\"%d\",\"%d\",\"%b\"\n", outPath, lineCnt, new File(outPath).length(), isAlign);
        }
    }

}
