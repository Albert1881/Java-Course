package cn.edu.sustech.cs209a.ass1;

import org.apache.tika.parser.txt.CharsetDetector;
import org.apache.tika.parser.txt.CharsetMatch;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class Utils8 {
    /**
     * write content to path (if not exist, then create it recursively) with specified encoding.
     *
     * @param content
     * @param path
     * @param charset
     */
    public static void writeAsEncoding(String content, String path, Charset charset) {
        //if not exist, then create it recursively
        createFileRecur(path);
        // TODO:  write content to path with specified encoding

        try (FileOutputStream fos = new FileOutputStream(new File(path));
             OutputStreamWriter osw = new OutputStreamWriter(fos, charset);
             BufferedWriter bWriter = new BufferedWriter(osw);) {
            bWriter.write(content);
            bWriter.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void createFileRecur(String path) {
        // TODO:  if not exist, then create it recursively
        File file = new File(path);
        if (file.exists() || path.endsWith(File.separator)) {
            return;
        }
        if (!file.getParentFile().exists()) {
            if (!file.getParentFile().mkdirs()) {
                return;
            }
        }
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return;
    }

    /**
     * detect the encoding of file and return the content as a string
     *
     * @param path the original file path
     * @return the content of file
     * @throws FileNotFoundException,IOException
     */
    public static String detectFromUnknownEncoding(String path) throws FileNotFoundException {
        // TODO: detect the encoding, read the original file, and return the content as a string
        // hint: refer to Example.java
        CharsetDetector charsetDetector = new CharsetDetector();
        String content = null;
        try {
            charsetDetector.setText(new BufferedInputStream(new FileInputStream(path)));
            CharsetMatch charsetMatch = charsetDetector.detect();
            content = charsetMatch.getString();
        } catch (IOException e) {
            throw new FileNotFoundException();
        }

        return content;
    }

    /**
     * load the properties
     *
     * @param path the path of properties file
     * @return The Properties
     * @throws FileNotFoundException,IOException
     */
    public static Properties loadProperties(String path) throws FileNotFoundException {
        // TODO: load the properties
        // hint: refer to Example.java
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream(path));
        } catch (IOException e) {
            throw new FileNotFoundException();
        }
        return properties;
    }



    /**
     * remove the additional quates of a string.
     * this method is used to process the csv.
     *
     * @param ori
     * @return real content
     */
    public static String removeQuotes(String ori) {
        StringBuilder sb = new StringBuilder();
        // TODO: remove the additional quates of a string.
        int len_ori = ori.length();
        if (len_ori < 2 || ori.charAt(0) != '\"' || ori.charAt(len_ori - 1) != '\"') {
            return null;
        }
        int quotes_count = 0;
        for (int i = 1; i < len_ori - 1; i++) {
            char c = ori.charAt(i);
            if (c == '"') {
                quotes_count += 1;
                if (quotes_count == 2) {
                    sb.append("\"");
                    quotes_count = 0;
                }
            } else {
                sb.append(c);
                if (quotes_count != 0) {
                    return null;
                }
            }
        }
        if (quotes_count != 0) {
            return null;
        }
        return sb.toString();
    }

    /**
     * the reverse method of {@link Utils8#removeQuotes(String)}
     *
     * @param ori
     * @return real content after add quotes
     */
    public static String addQuotes(String ori) {
        StringBuilder sb = new StringBuilder();
        sb.append('"');
        for (char c : ori.toCharArray()) {
            if (c == '"') {
                sb.append("\"\"");
            } else {
                sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    /**
     * read a line of the input csv file
     *
     * @param line
     * @param separator
     * @return
     */
    public static List<String> readCSVLine(String line, char separator) {
        List<String> re = new ArrayList<>();
        // TODO: read a line of the input csv file,
//        re = Arrays.asList(line.split(Character.toString(separator)).clone());
        int quote_count = 0;
        if (line == null || line.length() < 2) {
            return null;
        }
        int N = line.length();
        if (line.charAt(0) != '\"' || line.charAt(N - 1) != '\"') {
            return null;
        }
        quote_count = 1;
        int begin_str = 0;
        for (int i = 1; i < N - 1; i++) {
            char c = line.charAt(i);
            if (c == '\"') {
                quote_count += 1;
            } else if (c == separator) {
                if (quote_count == 0) {
                    return null;
                } else if (quote_count % 2 == 0) {
                    if (line.charAt(i - 1) != '\"' || line.charAt(i + 1) != '\"') {
                        return null;
                    }
                    String s = line.substring(begin_str, i);
                    begin_str = i + 1;
                    quote_count = 0;
                    re.add(s);
                }
            } else {
                if (quote_count % 2 != 1) {
                    return null;
                }
            }
        }
        quote_count += 1;
        if (quote_count % 2 == 1 || quote_count == 0) {
            return null;
        } else {
            String s = line.substring(begin_str, N);
            re.add(s);
            return re;
        }
    }
}
