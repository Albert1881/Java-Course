package cn.edu.sustech.cs209a.ass1;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Properties;

public class Main {
    public static void main(String[] args) throws IOException {
        // This part gives you a brief idea of how the text preprocessing program works.
        // You will not be able to compile and run the program now.
        // But don't worry! Check the methods one by one, and fill the empties with appropriate code,
        // then you can finish this task step by step.
        // Now go and start.
        // hint: You can also search for `TODO` to find all unfinished part.
        // hint: Before your start, read the `Example` class we provided.

        Properties properties;
        try {
            properties = Utils8.loadProperties(args[0]); // load the property file
        } catch (FileNotFoundException e) {
            // prompt user if no config file is given
            throw new IllegalArgumentException();
        }

        // TODO: Read values from config files into those given variables. Examples are given.
        String inputCSVPath =


        // TODO: read the contents of csv file into csvContents
        String[] csvContents =


        // TODO: recursively create summaryPath File
        String summaryPath =

        // TODO: recursively create errorPath File
        String errorPath =


        PrintWriter summaryPW = null, errorPW = null;
        for (int i = 1/* skip the first line, which is the header */; i < csvContents.length; i++) {
            List<String> l = Utils8.readCSVLine(csvContents[i], ',');
            String oriPath = Utils8.removeQuotes(l.get(0));
            try {
                processOneFile(properties, summaryPW, l, oriPath);
            } catch (MyFileException e) {
                if (errorPW != null) {
                    errorPW.printf("\"%s\",\"%d\"\n", oriPath, e.lineCnt);
                }
            }
        }
        if (summaryPW != null) {
            summaryPW.close();
        }
        if (errorPW != null) {
            errorPW.close();
        }
    }

    private static void processOneFile(Properties properties, PrintWriter summaryPW, List<String> l, String oriPath) throws MyFileException {
        String fileContent;
        char targetSeparator =
        String targetLineSeparator =
        try {
            fileContent = Utils8.detectFromUnknownEncoding(oriPath);
            // all content of the file
        } catch (FileNotFoundException e) {
            throw new MyFileException(-1);
        }
        char separator = Utils8.removeQuotes(l.get(2)).charAt(0);
        String[] fileLines = fileContent.split("(\r\n)|\n");// \r\n or \n
        int lineCnt =
        // used to record line count
        int currentLine = 0;
        // used to record the possible error (abnormal) line
        int columnOfFirstValidLine = 0;
        // used to detect align
        boolean columnFlag = true, isAlign = true;
        StringBuilder out = new StringBuilder();
        for (String line : fileLines) {
            // TODO: process each line according the requirements



            out.append(convertedline);
            out.append(targetLineSeparator);
        }
        String outPath = Utils8.removeQuotes(l.get(1));
        Utils8.writeAsEncoding(out.toString(), outPath,
                Charset.forName(properties.getProperty("TargetEncoding", "utf-8")));
        if (summaryPW != null) {
            summaryPW.printf("\"%s\",\"%d\",\"%d\",\"%b\"\n", outPath, lineCnt, new File(outPath).length(), isAlign);
        }
    }

}
