package cn.edu.sustech.cs209a.ass1;

import org.apache.tika.parser.txt.CharsetDetector;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Utils8 {
    /**
     * write content to path (if not exist, then create it recursively) with specified encoding.
     * @param content
     * @param path
     * @param charset
     */
    public static void writeAsEncoding(String content, String path, Charset charset) {
        //if not exist, then create it recursively
        createFileRecur(path);
        // TODO:  write content to path with specified encoding


    }

    public static void createFileRecur(String path){
        // TODO:  if not exist, then create it recursively

    }

    /**
     * detect the encoding of file and return the content as a string
     * @param path the original file path
     * @return the content of file
     * @throws FileNotFoundException,IOException
     */
    public static String detectFromUnknownEncoding(String path) throws FileNotFoundException {
        // TODO: detect the encoding, read the original file, and return the content as a string
        // hint: refer to Example.java
        return null;
    }

    /**
     * load the properties
     * @param path the path of properties file
     * @return The Properties
     * @throws FileNotFoundException,IOException
     */
    public static Properties loadProperties(String path) throws FileNotFoundException {
        // TODO: load the properties
        // hint: refer to Example.java
        return null;
    }

    /**
     * remove the additional quates of a string.
     * this method is used to process the csv.
     * @param ori
     * @return real content
     */
    public static String removeQuotes(String ori) {
        StringBuilder sb = new StringBuilder();
        // TODO: remove the additional quates of a string.


        return sb.toString();
    }

    /**
     * the reverse method of {@link Utils8.removeQuotes}
     * @param ori
     * @return real content after add quotes
     */
    public static String addQuotes(String ori) {
        StringBuilder sb = new StringBuilder();
        sb.append('"');
        for (char c : ori.toCharArray()) {
            if (c == '"') {
                sb.append("\"\"");
            } else {
                sb.append(c);
            }
        }
        sb.append('"');
        return sb.toString();
    }

    /**
     * read a line of the input csv file
     * @param line
     * @param separator
     * @return
     */
    public static List<String> readCSVLine(String line, char separator) {
        List<String> re = new ArrayList<>();
        // TODO: read a line of the input csv file,

        return re;
    }
}
