package StudentManagement;

import java.io.IOException;

import StudentManagement.model.PageTab;
import StudentManagement.model.Student;
import StudentManagement.view.*;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import javafx.stage.WindowEvent;

public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;
    private TabPane tabPane;
    private StudentOverviewController studentOverviewController;

    /**
     * Constructor
     */
    public MainApp() {

    }


    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("AddressApp");

        // Set the application icon.
        this.primaryStage.getIcons().add(new Image("file:resources/images/address_book_32.png"));

        initRootLayout();
//        showTanPaneOverview();
        showStudentOverview();
    }

    /**
     * Initializes the root layout and tries to load the last opened
     * person file.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class
                    .getResource("view/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);

            // Give the controller access to the main app.
            RootLayoutController controller = loader.getController();
            controller.setMainApp(this);
            primaryStage.show();
            primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent windowEvent) {
                    Object[] pageTabs = tabPane.getTabs().toArray();
                    for (Object pageTab : pageTabs
                    ) {
                        if (pageTab != null) {
                            ((PageTab) pageTab).closeTab();
                        }
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

//        // Try to load last opened person file.
//        File file = getPersonFilePath();
//        if (file != null) {
//            loadPersonDataFromFile(file);
//        }
    }

    /**
     * Shows the person overview inside the root layout.
     */
    public void showStudentOverview() {
        try {
            // Load person overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/StudentOverview.fxml"));
            AnchorPane studentOverview = (AnchorPane) loader.load();

            // Set person overview into the center of root layout.
            rootLayout.setCenter(studentOverview);

            // Give the controller access to the main app.
            studentOverviewController = loader.getController();
            studentOverviewController.setMainApp(this);
            tabPane = studentOverviewController.getTabPane();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Returns the main stage.
     *
     * @return
     */
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public StudentOverviewController getStudentOverviewController() {
        return studentOverviewController;
    }

    public TabPane getTabPane() {
        return tabPane;
    }


    /**
     * Opens a dialog to edit details for the specified Student. If the user
     * clicks OK, the changes are saved into the provided Student object and true
     * is returned.
     *
     * @param student the Student object to be edited
     * @return true if the user clicked OK, false otherwise.
     */
    public boolean showStudentEditDialog(Student student) {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/StudentEditDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Student");
            dialogStage.initModality(Modality.WINDOW_MODAL);

            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the Student into the controller.
            StudentEditDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setStudent(student);

            // Set the dialog icon.
            dialogStage.getIcons().add(new Image("file:resources/images/edit.png"));

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void showStudentSearchDialog() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/StudentSearchDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Please choose");
            dialogStage.initModality(Modality.WINDOW_MODAL);

            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            // Set the Student into the controller.
            StudentSearchDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            PageTab pageTab = (PageTab) tabPane.getSelectionModel().getSelectedItem();
            controller.setStudentTable(pageTab.getStudentTable());

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
            return;

        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
    }

    public void showStudentSearchAllDialog() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/StudentSearchAllDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Please choose");
            dialogStage.initModality(Modality.WINDOW_MODAL);

            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);
            // Set the Student into the controller.
            StudentSearchAllDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            PageTab pageTab = (PageTab) tabPane.getSelectionModel().getSelectedItem();
            controller.setMainApp(this);
            controller.setStudentTable(pageTab.getStudentTable());

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
            return;

        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}