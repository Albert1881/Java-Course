package StudentManagement.model;

import StudentManagement.MainApp;
import StudentManagement.util.DateUtil;
import StudentManagement.view.StudentEditDialogController;
import StudentManagement.view.StudentOverviewController;
import StudentManagement.view.StudentSaveController;
import StudentManagement.view.StudentTableController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Tab;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import org.apache.commons.csv.*;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.prefs.Preferences;

public class PageTab extends Tab {
    private static int PageTabID = 0;
    /**
     * The data as an observable list of Persons.
     */
    private ObservableList<Student> studentData = FXCollections.observableArrayList();
    private BorderPane tabLayout;
    private StudentOverviewController studentOverviewController;
    private TableView<Student> studentTable;
    private File file = null;
    private boolean isChanged = false;
    private boolean isSearch = false;
    private MainApp mainApp;

    public PageTab() {
        this.setText("Table " + PageTabID);
        PageTabID += 1;
        tabLayout = new BorderPane();
        setContent(tabLayout);
        showStudentOverview();
        isChanged = false;
        this.setOnCloseRequest(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                if (isSearch) {
                    studentOverviewController.setvisible();
                }
                if (isChanged) {
                    boolean okClicked = showStudentSaveDialog();
                    if (okClicked) {
                        boolean save = saveStudentDataToFile();
                        if (!save && event != null) {
                            event.consume();
                        }
                    }
                }

            }
        });

    }

    public boolean getSearch() {
        return isSearch;
    }

    public void setSearch(boolean isSearch) {
        this.isSearch = isSearch;
    }

    public PageTab(File file) {
        this.setText("Table " + PageTabID);
        PageTabID += 1;
        tabLayout = new BorderPane();
        setContent(tabLayout);
        showStudentOverview();
        isChanged = false;
        if (file != null) {
            loadStudentDataFromFile(file);
        }
        this.setOnCloseRequest(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                if (isSearch) {
                    studentOverviewController.setvisible();
                }
                if (isChanged) {
                    boolean okClicked = showStudentSaveDialog();
                    if (okClicked) {
                        boolean save = saveStudentDataToFile();
                        if (!save) {
                            event.consume();
                        }
                    }
                }
            }
        });

    }

    public boolean showStudentSaveDialog() {
        try {
            // Load the fxml file and create a new stage for the popup dialog.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/StudentSaveDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Create the dialog Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Save Students");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(mainApp.getPrimaryStage());
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the person into the controller.
            StudentSaveController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setPageTab(this);

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();

            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public boolean getChanged() {
        return isChanged;
    }

    public void setChanged(Boolean isChanged) {
        this.isChanged = isChanged;
    }


    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    /**
     * Returns the data as an observable list of Students.
     *
     * @return
     */
    public ObservableList<Student> getStudentData() {
        return studentData;
    }


    /**
     * Shows the Student overview inside the root layout.
     */
    public void showStudentOverview() {
        try {
            // Load Student overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("view/StudentTable.fxml"));
            AnchorPane StudentTableview = (AnchorPane) loader.load();

            // Set Student overview into the center of root layout.
            tabLayout.setCenter(StudentTableview);

            // Give the controller access to the main app.
            StudentTableController controller = loader.getController();
            controller.setPageTab(this);
            studentTable = controller.getStudentTable();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setStudentOverviewController(StudentOverviewController studentOverviewController) {
        this.studentOverviewController = studentOverviewController;
    }

    public StudentOverviewController getStudentOverviewController() {
        return studentOverviewController;
    }

    public TableView<Student> getStudentTable() {
        return studentTable;
    }

    /**
     * Loads person data from the specified file. The current person data will
     * be replaced.
     *
     * @param file
     */
    public void loadStudentDataFromFile(File file) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            final String[] HEADERS = {"ID", "Name", "Gender", "Department", "GPA", "Credit Earned", "Birthday"};

            // Demo: How to read a csv file
            Reader in = new FileReader(file);
            CSVParser parser = CSVFormat.RFC4180.withHeader(HEADERS)
                    .withFirstRecordAsHeader().withQuoteMode(QuoteMode.ALL).parse(in);
            List<CSVRecord> records = parser.getRecords();
            studentData.clear();
            String info = "";
            int line = 0;
            for (CSVRecord record : records) {
                line += 1;
                Student student = new Student();
                String ID = record.get("ID");
                String Name = record.get("Name");
                String Gender = record.get("Gender");
                String Department = record.get("Department");
                String GPA = record.get("GPA");
                String Credit = record.get("Credit Earned");
                String Birthday = record.get("Birthday");
                String message = isInputValid(ID, Name, Gender, Department, GPA, Credit, Birthday);

                if (message.length() == 0) {
                    student.setID(ID);
                    student.setName(Name);
                    student.setGender(Gender);
                    student.setDepartment(Department);
                    student.setGPA(Double.parseDouble(GPA));
                    student.setCredit(Integer.parseInt(Credit));
                    student.setBirthday(LocalDate.parse(Birthday));
                    studentData.add(student);
                } else {
                    info += "(Line )" + line + message + "\n";
                    this.isChanged = true;
                }
            }
            // Save the file path to the registry.
            setStudentFilePath(file);
            if (info.length() > 0) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Invalid input data");

                alert.setContentText(info);
                alert.showAndWait();
            }
        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not load data");
            if (file != null) {
                alert.setContentText("Could not load data from file:\n" + file.getPath());
            }
            alert.setContentText(e.getMessage());
            alert.showAndWait();
        }
    }

    public String isInputValid(String ID, String Name, String Gender, String Department, String GPA, String Credit, String Birthday) {
        String errorMessage = "";

        if (ID == null || ID.length() == 0) {
            errorMessage += "No valid ID!\n";
        }
        if (Name == null || Name.length() == 0) {
            errorMessage += "No valid name!\n";
        }
        if (Gender == null || !(Gender.equals("MALE") || Gender.equals("FEMALE"))) {
            errorMessage += "No valid Gender!\n";
        }
        if (Department == null || Department.length() == 0) {
            errorMessage += "No valid Department!\n";
        }

        if (GPA == null) {
            errorMessage += "No valid GPA!\n";
        } else {
            // try to parse the postal code into an int.
            try {
                Double GPA_value = Double.parseDouble(GPA);
                if (GPA_value < 0 || GPA_value > 4) {
                    errorMessage += "No valid GPA(must be in range [0.0, 4.0])!\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "No valid postal code (must be a double)!\n";
            }
        }

        if (Credit == null) {
            errorMessage += "No valid Credit!\n";
        } else {
            // try to parse the postal code into an int.
            try {
                Integer Credit_value = Integer.parseInt(Credit);

                if (Credit_value < 0) {
                    errorMessage += "No valid Credit(must be an integer greater than or equal 0)!\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "No valid postal code (must be an integer)!\n";
            }
        }


        if (Birthday == null) {
            errorMessage += "No valid birthday!\n";
        } else {
            if (!DateUtil.validDate(Birthday)) {
                errorMessage += "No valid birthday. Use the format yyyy-MM-dd!\n";
            }
        }

        return errorMessage;
    }

    /**
     * Saves the current Student data to the specified file.
     */
    public boolean saveStudentDataToFile() {
        if (file == null) {
            FileChooser fileChooser = new FileChooser();

            // Set extension filter
            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                    "CSV files (*.csv)", "*.csv");
            fileChooser.getExtensionFilters().add(extFilter);

            // Show save file dialog
            file = fileChooser.showSaveDialog(mainApp.getPrimaryStage());
        }
        try {
            final String[] HEADERS = {"ID", "Name", "Gender", "Department", "GPA", "Credit Earned", "Birthday"};

            // Demo: How to write a csv file
            FileWriter fw = new FileWriter(file);
            CSVPrinter printer = new CSVPrinter(fw, CSVFormat.RFC4180.withHeader(HEADERS).withQuoteMode(QuoteMode.ALL));
            for (Student student : studentData
            ) {
                printer.printRecord(student.getID(),
                        student.getName(),
                        student.getGender(),
                        student.getDepartment(),
                        String.valueOf(student.getGPA()),
                        String.valueOf(student.getCredit()),
                        DateUtil.format(student.getBirthday()));
            }
            fw.close();

            // Save the file path to the registry.
            setStudentFilePath(file);
            this.isChanged = false;

        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not save data");
            if (file != null) {
                alert.setContentText("Could not save data to file:\n" + file.getPath());
            }
            alert.showAndWait();
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    /**
     * Returns the Student file preference, i.e. the file that was last opened.
     * The preference is read from the OS specific registry. If no such
     * preference can be found, null is returned.
     *
     * @return
     */
    public File getStudentFilePath() {
        return this.file;
    }

    /**
     * Sets the file path of the currently loaded file. The path is persisted in
     * the OS specific registry.
     *
     * @param file the file or null to remove the path
     */
    public void setStudentFilePath(File file) {
        this.file = file;
    }

    public void closeTab() {
        EventHandler<Event> handler = this.getOnCloseRequest();
        if (isSearch) {
            studentOverviewController.setvisible();
        }
        if (null != handler) {
            handler.handle(null);
        } else {
            this.getTabPane().getTabs().remove(this);
        }
    }
}

