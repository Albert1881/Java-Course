package StudentManagement.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import StudentManagement.util.DateUtil;
import javafx.beans.property.*;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import StudentManagement.util.LocalDateAdapter;
import javafx.scene.control.Alert;

/**
 * Model class for a Student.
 *
 * @author Marco Jakob
 */
public class Student {

    private final StringProperty ID;
    private final StringProperty Name;
    private final StringProperty Gender;
    private final StringProperty Department;
    private final DoubleProperty GPA;
    private final IntegerProperty Credit;
    private final ObjectProperty<LocalDate> Birthday;

    /**
     * Default constructor.
     */
    public Student() {
        this(null, null, null, 0.0, 0);
    }

    /**
     * Constructor with some initial data.
     *
     * @param ID
     * @param Name
     */
    public Student(String ID, String Name, String Department, double GPA, int Credit) {
        this.ID = new SimpleStringProperty(ID);
        this.Name = new SimpleStringProperty(Name);
        this.Department = new SimpleStringProperty(Department);
        this.GPA = new SimpleDoubleProperty(GPA);
        this.Credit = new SimpleIntegerProperty(Credit);

        // Some initial dummy data, just for convenient testing.
        this.Gender = new SimpleStringProperty("MALE");
        this.Birthday = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
    }

    public String getID() {
        return ID.get();
    }

    public void setID(String ID) {
        this.ID.set(ID);
    }

    public StringProperty IDProperty() {
        return ID;
    }

    public String getName() {
        return Name.get();
    }

    public void setName(String Name) {
        this.Name.set(Name);
    }

    public StringProperty NameProperty() {
        return Name;
    }

    public String getGender() {
        return Gender.get();
    }

    public void setGender(String Gender) {
        this.Gender.set(Gender);
    }

    public StringProperty GenderProperty() {
        return Gender;
    }

    public String getDepartment() {
        return Department.get();
    }

    public void setDepartment(String Department) {
        this.Department.set(Department);
    }

    public StringProperty DepartmentProperty() {
        return Department;
    }

    public double getGPA() {
        return GPA.get();
    }

    public void setGPA(double GPA) {
        this.GPA.set(GPA);
    }

    public DoubleProperty GPAProperty() {
        return GPA;
    }

    public int getCredit() {
        return Credit.get();
    }

    public void setCredit(int Credit) {
        this.Credit.set(Credit);
    }

    public IntegerProperty CreditProperty() {
        return Credit;
    }

    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    public LocalDate getBirthday() {
        return Birthday.get();
    }

    public void setBirthday(LocalDate Birthday) {
        this.Birthday.set(Birthday);
    }

    public boolean search(String key) {
        ArrayList<String> info = new ArrayList<>();
        info.add(ID.get());
        info.add(Name.get());
        info.add(Gender.get());
        info.add(Department.get());
        info.add(String.valueOf(GPA.get()));
        info.add(String.valueOf(Credit.get()));
        info.add(DateUtil.format(Birthday.get()));
        Pattern pattern = Pattern.compile(key);
        for (int i = 0; i < info.size(); i++) {
            Matcher matcher = pattern.matcher(info.get(i));
            if (matcher.find()) {
                return true;
            }
        }
        return false;
    }

    public ObjectProperty<LocalDate> BirthdayProperty() {
        return Birthday;
    }

    public String getInfo() {
        String info = "";
        info += "ID: \t" + ID.get() + "\n";
        info += "Name: \t" + Name.get() + "\n";
        info += "Gender: \t" + Gender.get() + "\n";
        info += "Department: \t" + Department.get() + "\n";
        info += "GPA: \t" + String.valueOf(GPA.get()) + "\n";
        info += "Credit: \t" + String.valueOf(Credit.get()) + "\n";
        info += "Birthday: \t" + DateUtil.format(Birthday.get()) + "\n\n";
        return info;
    }
}