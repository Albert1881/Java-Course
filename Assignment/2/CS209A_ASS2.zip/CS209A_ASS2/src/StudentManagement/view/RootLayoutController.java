package StudentManagement.view;

import java.io.File;

import StudentManagement.model.PageTab;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TabPane;
import javafx.stage.FileChooser;
import StudentManagement.MainApp;

/**
 * The controller for the root layout. The root layout provides the basic
 * application layout containing a menu bar and space where other JavaFX
 * elements can be placed.
 *
 * @author Marco Jakob
 */
public class RootLayoutController {

    // Reference to the main application
    private MainApp mainApp;

    /**
     * Is called by the main application to give a reference back to itself.
     *
     * @param mainApp
     */
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
    }

    /**
     * Creates an empty address book.
     */
    @FXML
    private void handleNew() {
        PageTab pageTab = new PageTab();
        mainApp.getTabPane().getTabs().add(pageTab);
        mainApp.getTabPane().getSelectionModel().select(pageTab);
        pageTab.setMainApp(mainApp);
        pageTab.setStudentOverviewController(mainApp.getStudentOverviewController());
        pageTab.setChanged(true);
    }

    /**
     * Opens a FileChooser to let the user select an address book to load.
     */
    @FXML
    private void handleOpen() {
        FileChooser fileChooser = new FileChooser();

        // Set extension filter
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "XML files (*.csv)", "*.csv");
        fileChooser.getExtensionFilters().add(extFilter);

        // Show save file dialog
        File file = fileChooser.showOpenDialog(mainApp.getPrimaryStage());

        if (file != null) {
            PageTab pageTab = new PageTab(file);
            pageTab.setMainApp(mainApp);
            mainApp.getTabPane().getTabs().add(pageTab);
            mainApp.getTabPane().getSelectionModel().select(pageTab);
            pageTab.setStudentOverviewController(mainApp.getStudentOverviewController());

        }
    }

    /**
     * Saves the file to the person file that is currently open. If there is no
     * open file, the "save as" dialog is shown.
     */
    @FXML
    private void handleSave() {
        PageTab pageTab = (PageTab) mainApp.getTabPane().getSelectionModel().getSelectedItem();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        File studentFile = pageTab.getStudentFilePath();
        if (studentFile != null) {
            pageTab.setFile(studentFile);
            pageTab.saveStudentDataToFile();
        } else {
            handleSaveAs();
        }
    }

    /**
     * Opens a FileChooser to let the user select a file to save to.
     */
    @FXML
    private void handleSaveAs() {
        PageTab pageTab = (PageTab) mainApp.getTabPane().getSelectionModel().getSelectedItem();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        FileChooser fileChooser = new FileChooser();

        // Set extension filter
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(
                "CSV files (*.csv)", "*.csv");
        fileChooser.getExtensionFilters().add(extFilter);

        // Show save file dialog
        File file = fileChooser.showSaveDialog(mainApp.getPrimaryStage());

        if (file != null) {
            // Make sure it has the correct extension
            if (!file.getPath().endsWith(".csv")) {
                file = new File(file.getPath() + ".csv");
            }
            pageTab.setFile(file);
            pageTab.saveStudentDataToFile();
        }
    }

    /**
     * Opens an about dialog.
     */
    @FXML
    private void handleAbout() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("AddressApp");
        alert.setHeaderText("About");
        alert.setContentText("Author: Shaofeng Zhang");

        alert.showAndWait();
    }

    /**
     * Closes the application.
     */
    @FXML
    private void handleExit() {
        TabPane tabPane = mainApp.getTabPane();
        Object[] pageTabs = tabPane.getTabs().toArray();
        for (Object pageTab:pageTabs
             ) {
            if(pageTab!=null){
                ((PageTab)pageTab).closeTab();
            }
        }
        System.exit(0);
    }
    @FXML
    private void handleSearchNext() {
        PageTab pageTab = (PageTab) mainApp.getTabPane().getSelectionModel().getSelectedItem();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        mainApp.showStudentSearchDialog();
    }

    @FXML
    private void handleSearchAll() {
        PageTab pageTab = (PageTab) mainApp.getTabPane().getSelectionModel().getSelectedItem();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        mainApp.showStudentSearchAllDialog();
    }

}