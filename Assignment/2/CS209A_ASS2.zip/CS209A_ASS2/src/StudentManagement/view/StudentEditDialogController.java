package StudentManagement.view;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import StudentManagement.model.Student;
import StudentManagement.util.DateUtil;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

/**
 * Dialog to edit details of a person.
 *
 * @author Marco Jakob
 */
public class StudentEditDialogController {

    @FXML
    private TextField IDField;
    @FXML
    private TextField NameField;
    @FXML
    private ChoiceBox<String> GenderChoice;
    @FXML
    private TextField DepartmentField;
    @FXML
    private TextField GPAField;
    @FXML
    private TextField CreditField;
    @FXML
    private DatePicker BirthdayPicker;

    private final String pattern = "yyyy-MM-dd";
    private Stage dialogStage;
    private Student student;
    private boolean okClicked = false;
    public List<String> genderList = Arrays.asList("MALE", "FEMALE");
    private String gender = "MALE";

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        GenderChoice.setItems(FXCollections.observableArrayList(genderList));
        GenderChoice.setValue(gender);
        GenderChoice.getSelectionModel().select(0);
        GenderChoice.getSelectionModel().selectedIndexProperty()
                .addListener(new ChangeListener<Number>() {
                    public void changed(ObservableValue ov, Number value, Number new_value) {
                        if (new_value.intValue() >= 0 && new_value.intValue() < 2) {
                            gender = genderList.get(new_value.intValue());
                        } else {
                            gender = genderList.get(0);
                        }
                    }
                });

        StringConverter converter = new StringConverter<LocalDate>() {
            DateTimeFormatter dateFormatter =
                    DateTimeFormatter.ofPattern(pattern);

            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    return dateFormatter.format(date);
                } else {
                    return "";
                }
            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    return LocalDate.parse(string, dateFormatter);
                } else {
                    return null;
                }
            }
        };
        BirthdayPicker.setConverter(converter);
        BirthdayPicker.setPromptText(pattern.toLowerCase());
        BirthdayPicker.setValue(LocalDate.now());
    }

    /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    /**
     * Sets the student to be edited in the dialog.
     *
     * @param student
     */
    public void setStudent(Student student) {
        this.student = student;
        setGender(student.getGender());
        IDField.setText(student.getID());
        NameField.setText(student.getName());
        DepartmentField.setText(student.getDepartment());
        GPAField.setText(Double.toString(student.getGPA()));
        CreditField.setText(Integer.toString(student.getCredit()));
        BirthdayPicker.setValue(student.getBirthday());
    }

    public void setGender(String gender) {
        int index = genderList.indexOf(gender);
        GenderChoice.getSelectionModel().select(index);
        this.gender = gender;
    }

    /**
     * Returns true if the user clicked OK, false otherwise.
     *
     * @return
     */
    public boolean isOkClicked() {
        return okClicked;
    }


    /**
     * Called when the user clicks ok.
     */
    @FXML
    private void handleOk() {
        if (isInputValid()) {

            student.setID(IDField.getText());

            student.setName(NameField.getText());

            student.setGender(gender);

            student.setDepartment(DepartmentField.getText());

            student.setGPA(Double.parseDouble(GPAField.getText()));

            student.setCredit(Integer.parseInt(CreditField.getText()));

            student.setBirthday(BirthdayPicker.getValue());


            okClicked = true;
            dialogStage.close();
        }
    }

    /**
     * Called when the user clicks cancel.
     */
    @FXML
    private void handleCancel() {
        dialogStage.close();
    }

    /**
     * Validates the user input in the text fields.
     *
     * @return true if the input is valid
     */
    private boolean isInputValid() {
        String errorMessage = "";

        if (IDField.getText() == null || IDField.getText().length() == 0) {
            errorMessage += "No valid ID!\n";
        }
        if (NameField.getText() == null || NameField.getText().length() == 0) {
            errorMessage += "No valid name!\n";
        }
        if (gender == null) {
            errorMessage += "No valid Gender!\n";
        }
        if (DepartmentField.getText() == null || DepartmentField.getText().length() == 0) {
            errorMessage += "No valid Department!\n";
        }

        if (GPAField.getText() == null || GPAField.getText().length() == 0) {
            errorMessage += "No valid GPA!\n";
        } else {
            // try to parse the postal code into an int.
            try {
                double GPA = Double.parseDouble(GPAField.getText());
                if (GPA < 0 || GPA > 4) {
                    errorMessage += "No valid GPA(must be in range [0.0, 4.0])!\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "No valid postal code (must be a double)!\n";
            }
        }

        if (CreditField.getText() == null || CreditField.getText().length() == 0) {
            errorMessage += "No valid Credit!\n";
        } else {
            // try to parse the postal code into an int.
            try {
                int Credit = Integer.parseInt(CreditField.getText());
                if (Credit < 0) {
                    errorMessage += "No valid Credit(must be an integer greater than or equal 0)!\n";
                }
            } catch (NumberFormatException e) {
                errorMessage += "No valid postal code (must be an integer)!\n";
            }
        }


        if (BirthdayPicker.getValue() == null) {
            errorMessage += "No valid birthday!\n";
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
            // Show the error message.
            Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Invalid Fields");
            alert.setHeaderText("Please correct invalid fields");
            alert.setContentText(errorMessage);

            alert.showAndWait();

            return false;
        }
    }
}