package StudentManagement.view;

import StudentManagement.MainApp;
import StudentManagement.model.PageTab;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import StudentManagement.model.Student;
import StudentManagement.util.DateUtil;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

public class StudentOverviewController {


    @FXML
    private Label IDLabel;
    @FXML
    private Label NameLabel;
    @FXML
    private Label GenderLabel;
    @FXML
    private Label DepartmentLabel;
    @FXML
    private Label GPALabel;
    @FXML
    private Label CreditLabel;
    @FXML
    private Label BirthdayLabel;

    @FXML
    private Button NewButton;
    @FXML
    private Button EditButton;
    @FXML
    private Button DeleteButton;

    @FXML
    private GridPane gridPane;

    @FXML
    private AnchorPane DetailPane;

    @FXML
    private TabPane tabPane;

    // Reference to the main application.
    private MainApp mainApp;
    private TextArea area;
    private Button FinishButton;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public StudentOverviewController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {

        tabPane.getTabs().clear();
        tabPane.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> observable, Tab oldValue, Tab newValue) {
                PageTab pageTab = (PageTab) newValue;
                if (pageTab != null) {
                    showStudentDetails(pageTab.getStudentTable().getSelectionModel().getSelectedItem());
                } else {
                    showStudentDetails(null);
                }
            }
        });
        // Clear person details.
        showStudentDetails(null);

    }

    public GridPane getGridPane() {
        return gridPane;
    }

    public AnchorPane getDeatilPane() {
        return DetailPane;
    }

    /**
     * Is called by the main application to give a reference back to itself.
     *
     * @param mainApp
     */
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        area = new TextArea(); // 创建一个多行输入框
        area.setMaxWidth(300); // 设置多行输入框的最大宽度
        area.setPrefSize(400, 500); // 设置多行输入框的推荐宽高
        FinishButton = new Button("Finish");
        DetailPane.getChildren().addAll(area, FinishButton);
        DetailPane.setLeftAnchor(area, 100.0);
        DetailPane.setTopAnchor(area, 100.0);
        DetailPane.setRightAnchor(FinishButton, 100.0);
        DetailPane.setBottomAnchor(FinishButton, 10.0);
        area.visibleProperty().set(false);
        FinishButton.visibleProperty().set(false);
        FinishButton.setOnMouseClicked(new EventHandler<Event>() {
            @Override
            public void handle(Event event) {
                setvisible();
                getSelectedPageTab().getStudentTable().getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            }
        });
        // Add observable list data to the table
//        studentTable.setItems(pageTab.getStudentData());
    }

    /**
     * Fills all text fields to show details about the person.
     * If the specified person is null, all text fields are cleared.
     *
     * @param student the person or null
     */
    public void showStudentDetails(Student student) {
        if (student != null) {
            // Fill the labels with info from the person object.
            IDLabel.setText(student.getID());
            NameLabel.setText(student.getName());
            GenderLabel.setText(student.getGender());
            DepartmentLabel.setText(student.getDepartment());
            GPALabel.setText(Double.toString(student.getGPA()));
            CreditLabel.setText(Integer.toString(student.getCredit()));
            BirthdayLabel.setText(DateUtil.format(student.getBirthday()));

        } else {
            // Person is null, remove all the text.
            IDLabel.setText("");
            NameLabel.setText("");
            GenderLabel.setText("");
            DepartmentLabel.setText("");
            GPALabel.setText("");
            CreditLabel.setText("");
            BirthdayLabel.setText("");
        }
    }

    /**
     * Called when the user clicks on the delete button.
     */
    @FXML
    private void handleDeletePerson() {
        PageTab pageTab = getSelectedPageTab();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        int selectedIndex = pageTab.getStudentTable().getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            pageTab.getStudentTable().getItems().remove(selectedIndex);
            pageTab.setChanged(true);
        } else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Person Selected");
            alert.setContentText("Please select a person in the table.");
            alert.showAndWait();
        }
    }

    public PageTab getSelectedPageTab() {
        return (PageTab) tabPane.getSelectionModel().getSelectedItem();
    }

    /**
     * Called when the user clicks the new button. Opens a dialog to edit
     * details for a new person.
     */
    @FXML
    private void handleNewPerson() {
        PageTab pageTab = getSelectedPageTab();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        Student tempStudent = new Student();
        boolean okClicked = mainApp.showStudentEditDialog(tempStudent);
        if (okClicked) {
            pageTab.setChanged(true);
            pageTab.getStudentData().add(tempStudent);
            pageTab.getStudentTable().getSelectionModel().select(tempStudent);
        }
    }

    @FXML
    private void handleSearch() {
        PageTab pageTab = getSelectedPageTab();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }

    }

    /**
     * Called when the user clicks the edit button. Opens a dialog to edit
     * details for the selected person.
     */
    @FXML
    private void handleEditPerson() {
        PageTab pageTab = getSelectedPageTab();
        if (pageTab == null) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No PageTab");
            alert.setHeaderText("No PageTab Opened");
            alert.setContentText("Please open a pageTab.");
            alert.showAndWait();
            return;
        }
        Student selectedStudent = pageTab.getStudentTable().getSelectionModel().getSelectedItem();
        if (selectedStudent != null) {
            boolean okClicked = mainApp.showStudentEditDialog(selectedStudent);
            if (okClicked) {
                pageTab.setChanged(true);
                showStudentDetails(selectedStudent);
            }
        } else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Person Selected");
            alert.setContentText("Please select a person in the table.");

            alert.showAndWait();
        }
    }

    public TabPane getTabPane() {
        return tabPane;
    }


    public void setUnvisible() {
        getSelectedPageTab().setSearch(true);
        gridPane.visibleProperty().set(false);
        NewButton.visibleProperty().set(false);
        EditButton.visibleProperty().set(false);
        DeleteButton.visibleProperty().set(false);
        area.visibleProperty().set(true);
        FinishButton.visibleProperty().set(true);


    }

    public void setvisible() {
        getSelectedPageTab().setSearch(false);
        gridPane.visibleProperty().set(true);
        NewButton.visibleProperty().set(true);
        EditButton.visibleProperty().set(true);
        DeleteButton.visibleProperty().set(true);
        area.visibleProperty().set(false);
        area.setText("");
        FinishButton.visibleProperty().set(false);

    }

    public TextArea getArea() {
        return area;
    }
}