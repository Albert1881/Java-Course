package StudentManagement.view;

import StudentManagement.model.PageTab;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.awt.*;

/**
 * Dialog to edit details of a person.
 *
 * @author Marco Jakob
 */
public class StudentSaveController {

    private Stage dialogStage;
    private PageTab pageTab;
    private boolean okClicked = false;

    @FXML
    private Label tabLable;


    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
    }

    /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    /**
     * Sets the student to be edited in the dialog.
     *
     * @param pageTab
     */
    public void setPageTab(PageTab pageTab) {
        this.pageTab = pageTab;
        tabLable.setText(pageTab.getText());
    }

    /**
     * Returns true if the user clicked OK, false otherwise.
     *
     * @return
     */
    public boolean isOkClicked() {
        return okClicked;
    }

    /**
     * Called when the user clicks ok.
     */
    @FXML
    private void handleOk() {
        okClicked = true;
        dialogStage.close();
    }

    /**
     * Called when the user clicks cancel.
     */
    @FXML
    private void handleCancel() {
        okClicked = false;
        dialogStage.close();
    }

}