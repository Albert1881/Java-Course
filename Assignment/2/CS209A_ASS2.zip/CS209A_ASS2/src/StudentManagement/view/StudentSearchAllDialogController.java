package StudentManagement.view;

import StudentManagement.MainApp;
import StudentManagement.model.Student;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.util.ArrayList;

/**
 * Dialog to edit details of a person.
 *
 * @author Marco Jakob
 */
public class StudentSearchAllDialogController {

    @FXML
    private TextField SearchField;
    private Stage dialogStage;
    private TableView<Student> studentTable;
    private StudentOverviewController studentOverviewController;
    private AnchorPane DetailPane;
    private MainApp mainApp;

    private int count = -1;
    private ArrayList<Student> studentList = new ArrayList<>();

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        SearchField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                count = -1;
                studentList.clear();
            }
        });


    }

    private TextArea area;

    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;
        studentOverviewController = mainApp.getStudentOverviewController();
        studentOverviewController.setUnvisible();

        DetailPane = studentOverviewController.getDeatilPane();

    }

    public void setStudentTable(TableView<Student> studentTable) {
        this.studentTable = studentTable;
        this.studentTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }


    /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }


    public int getCount() {
        return count;
    }

    /**
     * Called when the user clicks ok.
     */
    @FXML
    private void handleAll() {
        studentTable.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        studentTable.getSelectionModel().clearSelection();
        Object[] students = studentTable.getItems().toArray();
        for (Object object : students
        ) {
            Student student = (Student) object;
            if (student.search(SearchField.getText())) {
                studentList.add(student);
            }
        }
        String results = "Find " + studentList.size() + "rows.\n";
        int c = 0;
        if (studentList.size() > 0) {
            for (Student student : studentList
            ) {
                results += "Num. " + c + "\n";
                results += student.getInfo();
                studentTable.getSelectionModel().select(student);
                c += 1;
            }
            studentOverviewController.getArea().setText(results);
        } else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(dialogStage);
            alert.setTitle("Search Not Find");
            alert.setHeaderText("Please choose other keys");
            alert.showAndWait();
        }
        dialogStage.close();
    }
}