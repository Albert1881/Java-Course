package StudentManagement.view;

import StudentManagement.model.Student;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.util.StringConverter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Dialog to edit details of a person.
 *
 * @author Marco Jakob
 */
public class StudentSearchDialogController {

    @FXML
    private TextField SearchField;
    private Stage dialogStage;
    private TableView<Student> studentTable;
    private int count = -1;
    private ArrayList<Student> studentList = new ArrayList<>();

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        SearchField.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                count = -1;
                studentList.clear();
            }
        });
    }

    public void setStudentTable(TableView<Student> studentTable) {
        this.studentTable = studentTable;
    }

    /**
     * Sets the stage of this dialog.
     *
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }


    public int getCount() {
        return count;
    }

    /**
     * Called when the user clicks ok.
     */
    @FXML
    private void handleNext() {
        if (count < 0) {
            count = 0;
            Object[] students = studentTable.getItems().toArray();
            for (Object object : students
            ) {
                Student student = (Student) object;
                if (student.search(SearchField.getText())) {
                    studentList.add(student);
                }
            }
        }
        if(studentList.size()>0) {
            studentTable.getSelectionModel().select(studentList.get(count));
            count = (count + 1) % studentList.size();
        }else {
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(dialogStage);
            alert.setTitle("Search Not Find");
            alert.setHeaderText("Please choose other keys");
            alert.showAndWait();
        }
    }

}