package StudentManagement.view;

import StudentManagement.MainApp;
import StudentManagement.model.PageTab;
import StudentManagement.model.Student;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class StudentTableController {
    @FXML
    private TableView<Student> studentTable;
    @FXML
    private TableColumn<Student, String> IDColumn;
    @FXML
    private TableColumn<Student, String> NameColumn;
    @FXML
    private TableColumn<Student, String> DepartmentColumn;
    @FXML
    private TableColumn<Student, Number> GPAColumn;
    @FXML
    private TableColumn<Student, Number> CreditColumn;

    private PageTab pageTab;

    public StudentTableController() {

    }

    @FXML
    private void initialize() {

        // Initialize the person table with the two columns.
        IDColumn.setCellValueFactory(cellData -> cellData.getValue().IDProperty());
        NameColumn.setCellValueFactory(cellData -> cellData.getValue().NameProperty());
        DepartmentColumn.setCellValueFactory(cellData -> cellData.getValue().DepartmentProperty());
        GPAColumn.setCellValueFactory(cellData -> cellData.getValue().GPAProperty());
        CreditColumn.setCellValueFactory(cellData -> cellData.getValue().CreditProperty());
        // Listen for selection changes and show the person details when changed.

        // Load Student overview.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(MainApp.class.getResource("view/StudentTable.fxml"));
        StudentTableController controller = loader.getController();
        studentTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> pageTab.getStudentOverviewController().showStudentDetails(newValue));

    }

    public TableView<Student> getStudentTable() {
        return studentTable;
    }

    public void setPageTab(PageTab pageTab) {
        this.pageTab = pageTab;
        // Add observable list data to the table
        studentTable.setItems(pageTab.getStudentData());
    }
}
