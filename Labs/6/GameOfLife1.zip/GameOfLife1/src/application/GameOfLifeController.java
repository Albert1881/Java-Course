package application;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class GameOfLifeController {
	@FXML
	TextArea gridTextArea;
	@FXML
	TextField generationTextField;
	@FXML
	Button playButton;
	@FXML
	Button pauseButton;
	@FXML
	Button preset1Button;
	@FXML
	Button preset2Button;
	@FXML
	Button preset3Button;

	PlayController playController;

	int[][] grid;

	int[][] blockPattern = { { 0, 0, 0, 0 }, { 0, 1, 1, 0 }, { 0, 1, 1, 0 }, { 0, 0, 0, 0 } };

	int[][] blinkerPattern = { { 0, 0, 0, 0, 0 }, { 0, 0, 1, 0, 0 }, { 0, 0, 1, 0, 0 }, { 0, 0, 1, 0, 0 },
			{ 0, 0, 0, 0, 0 } };

	int[][] gliderPattern = { { 0, 0, 0, 0, 0 }, { 0, 0, 1, 0, 0 }, { 0, 0, 0, 1, 0 }, { 0, 1, 1, 1, 0 },
			{ 0, 0, 0, 0, 0 }

	};

	int generation;
	int M = 10, N = 10;
    int flag;
    final int PLAY = 0;
    final int PAUSE = 1;
    final int STOP = 2;
    
	void init(int[][] pattern, int M, int N) {
		if ((pattern.length > M) || (pattern[0].length > N)) {
			return;
		}

		grid = new int[M][N];
		int offsetM = (M - pattern.length) / 2;
		int offsetN = (N - pattern[0].length) / 2;

		for (int i = 0; i < pattern.length; i++) {
			for (int j = 0; j < pattern[0].length; j++) {
				grid[i + offsetM][j + offsetN] = pattern[i][j];
			}
		}
	}

	String gridToString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				if (grid[i][j] == 0) {
					sb.append(".");
				} else {
					sb.append("*");
				}
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	void displayGrid(int grid[][], int M, int N) {
		for (int i = 0; i < M; i++) {
			for (int j = 0; j < N; j++) {
				if (grid[i][j] == 0)
					System.out.print(".");
				else
					System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
	}

	void nextGeneration() {
		int[][] future = new int[M][N];

		// Loop through every cell
		for (int l = 1; l < M - 1; l++) {
			for (int m = 1; m < N - 1; m++) {
				// finding no Of Neighbours that are alive
				int aliveNeighbours = 0;
				for (int i = -1; i <= 1; i++)
					for (int j = -1; j <= 1; j++)
						aliveNeighbours += grid[l + i][m + j];

				// The cell needs to be subtracted from
				// its neighbours as it was counted before
				aliveNeighbours -= grid[l][m];

				// Implementing the Rules of Life

				// Cell is lonely and dies
				if ((grid[l][m] == 1) && (aliveNeighbours < 2))
					future[l][m] = 0;

				// Cell dies due to over population
				else if ((grid[l][m] == 1) && (aliveNeighbours > 3))
					future[l][m] = 0;

				// A new cell is born
				else if ((grid[l][m] == 0) && (aliveNeighbours == 3))
					future[l][m] = 1;

				// Remains the same
				else
					future[l][m] = grid[l][m];
			}
		}
		for (int i = 0; i < M; i++) {
			System.arraycopy(future[i], 0, grid[i], 0, N);
		}
		generation++;

		System.out.printf("Generation: %2d\n", generation);
		displayGrid(grid, M, N);

	}
	
	public void updateGenerationTextField(){
		generationTextField.setText(String.valueOf(generation));
	}
	
	public void updateGridTextArea(){
		gridTextArea.setText(gridToString());
	}
	

	/**
	 * Initializes the controller class. This method is automatically called
	 * after the fxml file has been loaded.
	 */
	@FXML
	public void initialize() {
		generation = 0;
		init(blockPattern, M, N);
		generationTextField.setText(String.valueOf(generation));
		gridTextArea.setText(gridToString());
		playController = new PlayController(this, PAUSE);
		playController.start();
	}

	public void stop() {
		playController.setFlag(STOP);
	}

	/**
	 * Called when the user clicks on play button.
	 */
	@FXML
	private void handlePlay() {

		playController.setFlag(PLAY);

	}

	/**
	 * Called when the user clicks on the Pause button.
	 */
	@FXML
	private void handlePause() {
		playController.setFlag(PAUSE);
	}

	/**
	 * Called when the user clicks on the Preset1 button.
	 */
	@FXML
	private void handlePreset1() {
		playController.setFlag(PAUSE);
		generation = 0;
		init(blockPattern, M, N);
	}

	/**
	 * Called when the user clicks on the Preset2 button.
	 */
	@FXML
	private void handlePreset2() {
		playController.setFlag(PAUSE);
		generation = 0;
		init(blinkerPattern, M, N);

	}

	/**
	 * Called when the user clicks on the Preset3 button.
	 */
	@FXML
	private void handlePreset3() {
		playController.setFlag(PAUSE);
		generation = 0;
		init(gliderPattern, M, N);
	}
	

	

}

class PlayController extends Thread {
	GameOfLifeController gameOfLifeController;
	private volatile int flag;

	PlayController(GameOfLifeController gameOfLifeController, int flag) {
		this.gameOfLifeController = gameOfLifeController;
		this.flag = flag; // 0:play 1:pause 2:stop
	}

	public void setFlag(int flag) {
		this.flag = flag; // 0:play 1:pause 2:stop
	}

	@Override
	public void run() {
		while (flag != 2) {
			if (flag == 0) {
				gameOfLifeController.nextGeneration();
				gameOfLifeController.updateGenerationTextField();
				gameOfLifeController.updateGridTextArea();
				try {
					sleep(500);
				} catch (InterruptedException e) {
					if (Thread.interrupted()) { // Clears interrupted status!
						System.out.println("interrupted status");
					}
				}
			} else if (flag == 1) {
				try {
					if (gameOfLifeController.generation == 0) {
						gameOfLifeController.updateGenerationTextField();
						gameOfLifeController.updateGridTextArea();
					}
					sleep(200);
				} catch (InterruptedException e) {
					if (Thread.interrupted()) { // Clears interrupted status!
						System.out.println("interrupted status");
					}
				}
			}
		}
	}
}
